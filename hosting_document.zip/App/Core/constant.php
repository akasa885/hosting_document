<?php
define('baseurl','http://localhost/hosting_document/');

define('loginfirst',baseurl.'login/');

define('baseaset',baseurl.'Assets/');


// MySQL DATABASE
define('database_name','doc_hosting');
define('database_user','root');
define('database_pass', '1745ra');

?>
