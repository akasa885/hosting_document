<?php

require_once 'Core/app.php';
require_once 'Core/controller.php';
require_once 'Core/constant.php';
