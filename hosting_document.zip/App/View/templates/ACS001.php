    <h1>Access Deny!!!</h1>
    <h2>[err001]Cannot access in current date!</h2>
    <p>Harap akses pada hari yang ditentukan!!</p>
