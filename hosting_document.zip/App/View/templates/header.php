<html>
<head>
  <meta charset="utf-8">
  <title><?=$data['judul']?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Tempat uji coba membangun website kecil-kecilan.">
  <meta name="keywords" content="UPN, UPN VETERAN JATIM, upn veteran jawa timur, sistem informasi, SISTEM INFORMASI, teknik informatika, TEKNIK INFORMATIKA, komunitas website upn, KOMUNITAS WEBSITE UPN">
  <script type="text/javascript" src="<?=baseaset?>jquery/jquery-3.2.1.min.js"></script>
  <link rel="stylesheet" type="text/css" href="<?=baseaset?>style.css">
</head>
<body>
 <div class="main_media">
   <div class="mobile_only">
     <h3>Sorry Our Service Can Only Access On Mobile !!!</h3>
     <h4>Re-open Our Websites Using Browsers On Your Smarthphone and Enjoy The Build</h4>
   </div>
   <div class="loading">
     <div class="ball"></div>
     <div class="ball"></div>
     <div class="ball"></div>
     <div class="ball"></div>
   </div>
