<?php

/**
 *
 */
class users
{

  protected $con;

  function __construct()
  {
    $this->con = new db();
  }

  function select($username, $pass)
  {
    $sql = "select * from users where username = ".$username;

    if (password_verify($pass,$data['password'])) {
      // code...
    }else{

    }
  }

  function add($req)
  {
    $encryp = password_hash($pas,PASSWORD_BCRYPT);
    $sql = "insert into users (kode_user,username,password) values ()";
  }

}


 ?>
