<?php

class db{
    public $con;

    public function __construct()
    {
        $this -> con = mysqli_connect(localhost,database_user,database_pass);
        mysqli_select_db($this -> con,database_name);
    }
    public function proses ($sql) {
        return mysqli_query($this -> con, $sql);
    }
}

?>
