<?php
class forbidden extends controller
{

  // function __construct(argument)
  // {
  //   // code...
  // }
  public function index()
  {
    $this->view('templates/403');
  }
}

 ?>
