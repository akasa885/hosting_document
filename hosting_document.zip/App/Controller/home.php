<?php
 class home extends controller
 {
   public function index()
   {
     session_start();
     $data['judul']='Dashboard';
     $data['username']=$this->model('usercek')->get_user();
     if($data['username']==="guest"){
       header('Location:'.loginfirst);
     }else{
       //---------
       $this->view('templates/header',$data);
       //---------
       //---------
       $this->view('home/Dasboard',$data);
       //---------
       $this->view('templates/footer');
     }
   }
 }
