<?php
require_once 'App/init.php';
$app = new App('absensi');
